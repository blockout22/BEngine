package game;

import org.lwjgl.util.vector.Vector2f;
import org.lwjgl.util.vector.Vector3f;

import engine.Window;
import engine.camera.Camera;
import engine.entity.Entity;
import engine.mesh.Mesh;

public class BEngineGame{
	
	private GameShader shader;
	private Camera camera;
	
	private Mesh mesh;
	private Entity entity;
	
	public BEngineGame()
	{
		Window.createWindow(800, 600);
		Window.enableDepthBuffer();
		
		shader = new GameShader();
		camera = new Camera(70, Window.getAspectRatio(), 0.1f, 100f);
		mesh = new Mesh(shader.getProjectionMatrixLocation(), shader, "image0.png", camera);
		mesh.add(getVectorVertices(), getVectorTexCoords(), getIndices());
		entity = new Entity(mesh, new Vector3f(0, 0, -20), 0, 0, 0, 1);
		
		while(!Window.isCloseRequested())
		{
			Window.clearAll(0, 0, 0, 1);
			
			camera.move();
			shader.bind();
			shader.loadViewMatrix(camera);
			mesh.draw(shader.getModelMatrixLocation(), entity);
			shader.unbind();
			
			Window.sync(60);
			Window.update();
		}
		
		Window.close();
	}
	
	private int[] getIndices() {
		int[] indices = new int[] {
				//
				0, 1, 2, //
				2, 3, 0 //
		};

		return indices;
	}

	// Vector

	private Vector3f[] getVectorVertices() {
		Vector3f[] vertices = new Vector3f[] {
				//
				new Vector3f(-1f, -1f, -2f), // Left top ID: 0
				new Vector3f(0f, 1f, -2f), // Left bottom ID: 1
				new Vector3f(1f, -1f, -2f), // Right bottom ID: 2
				new Vector3f(0f, -1f, -2f) // Right left ID: 3

		};

		return vertices;
	}

	private Vector2f[] getVectorTexCoords() {
		Vector2f[] texCoords = new Vector2f[] {
				//
				new Vector2f(0, 0), //
				new Vector2f(0, 1), //
				new Vector2f(1, 1), //
				new Vector2f(1, 0) //

		};

		return texCoords;
	}
	
	public static void main(String[] args)
	{
		new BEngineGame();
	}
}

